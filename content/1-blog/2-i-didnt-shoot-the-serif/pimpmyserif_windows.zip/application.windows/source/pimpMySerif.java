import processing.core.*; 
import processing.xml.*; 

import controlP5.*; 

import java.applet.*; 
import java.awt.Dimension; 
import java.awt.Frame; 
import java.awt.event.MouseEvent; 
import java.awt.event.KeyEvent; 
import java.awt.event.FocusEvent; 
import java.awt.Image; 
import java.io.*; 
import java.net.*; 
import java.text.*; 
import java.util.*; 
import java.util.zip.*; 
import java.util.regex.*; 

public class pimpMySerif extends PApplet {

public void setup(){
  size(500,500);

  noStroke();
  smooth();


  controlP5 = new ControlP5(this);

  controlP5.addSlider("hauteur",100,295,250,250,340,150,10).setColorBackground(color(255,255,255));
  controlP5.addSlider("mediane",100,300,280,250,360,150,10).setColorBackground(color(255,255,255));
  controlP5.addSlider("courbe",250,295,200,250,380,150,10).setColorBackground(color(255,255,255));
  controlP5.addSlider("largeur",30,100,30,250,400,150,10).setColorBackground(color(255,255,255));
  controlP5.addSlider("symetrie",-70,70,0,250,420,150,10).setColorBackground(color(255,255,255));
  controlP5.addSlider("arc_inferieur",280,320,300,250,440,150,10).setColorBackground(color(255,255,255));
  controlP5.addSlider("extremite",-10,50,0,250,460,150,10).setColorBackground(color(255,255,255));

  controlP5.addButton("fin",10,50,340,150,15).setColorBackground(color(0,0,0));
  controlP5.addButton("carre",10,50,360,150,15).setColorBackground(color(0,0,0));
  controlP5.addButton("triangulaire",10,50,380,150,15).setColorBackground(color(0,0,0));
  controlP5.addButton("arrondi",10,50,400,150,15).setColorBackground(color(0,0,0));
  controlP5.addButton("arque",10,50,420,150,15).setColorBackground(color(0,0,0));

  controlP5.controller("fin").setColorActive(color(250,220,0));
  controlP5.controller("carre").setColorActive(color(250,220,0));
  controlP5.controller("triangulaire").setColorActive(color(250,220,0));
  controlP5.controller("arrondi").setColorActive(color(250,220,0));
  controlP5.controller("arque").setColorActive(color(250,220,0));
  
   controlP5.addButton("x1",10,370,5,20,15).setColorBackground(color(0,0,0));
  controlP5.addButton("x2",10,400,5,20,15).setColorBackground(color(0,0,0));
  controlP5.addButton("x3",10,430,5,20,15).setColorBackground(color(0,0,0));
  controlP5.addButton("x4",10,460,5,20,15).setColorBackground(color(0,0,0));

controlP5.controller("x1").setColorActive(color(250,220,0));
controlP5.controller("x2").setColorActive(color(250,220,0));
controlP5.controller("x3").setColorActive(color(250,220,0));
controlP5.controller("x4").setColorActive(color(250,220,0));

  controlP5.controller("hauteur").setColorForeground(color(250,220,0));
  controlP5.controller("mediane").setColorForeground(color(250,220,0));
  controlP5.controller("courbe").setColorForeground(color(250,220,0));
  controlP5.controller("largeur").setColorForeground(color(250,220,0));
  controlP5.controller("symetrie").setColorForeground(color(250,220,0));
  controlP5.controller("arc_inferieur").setColorForeground(color(250,220,0));
  controlP5.controller("extremite").setColorForeground(color(250,220,0));

  controlP5.controller("hauteur").setColorValue(color(0,0,0));
  controlP5.controller("mediane").setColorValue(color(0,0,0));
  controlP5.controller("courbe").setColorValue(color(0,0,0));
  controlP5.controller("largeur").setColorValue(color(0,0,0));
  controlP5.controller("symetrie").setColorValue(color(0,0,0));
  controlP5.controller("arc_inferieur").setColorValue(color(0,0,0));
  controlP5.controller("extremite").setColorValue(color(0,0,0));

  controlP5.controller("hauteur").setColorActive(color(0,0,0));
  controlP5.controller("mediane").setColorActive(color(0,0,0));
  controlP5.controller("courbe").setColorActive(color(0,0,0));
  controlP5.controller("largeur").setColorActive(color(0,0,0));
  controlP5.controller("symetrie").setColorActive(color(0,0,0));
  controlP5.controller("arc_inferieur").setColorActive(color(0,0,0)); 
  controlP5.controller("extremite").setColorActive(color(0,0,0)); 
}

public void draw(){

  background(50);
  fill(250,220,0);
  rect(0,25,500,300);
  noFill();

  pushMatrix();
  translate(250,0);

  fill(0);

  triangle(-30,100,30,100,30,78);

  stroke(255,255,255);
  strokeWeight(2);
  line(-50,105,50,70);
  noStroke();



  beginShape();
  vertex(x1,y1);
  /* 1 */  bezierVertex(x1,y1,x1,y1,x2,y2);

  /* 2 */  bezierVertex(x2,y2,x2,y2,x2,hauteurY);
  /* 3 */  bezierVertex(x2,hauteurY,x2,courbeY,largeurX+symetrieX,medianeY);
  /* 4 */  bezierVertex(largeurX+symetrieX,medianeY,largeurX+symetrieX,medianeY,largeurX+symetrieX,medianeY);
  /* 5 */  bezierVertex(largeurX+symetrieX,medianeY,largeurX+symetrieX+extremite,290,largeurX+symetrieX,300);

  /* 6 */  bezierVertex(largeurX+symetrieX,300,0,arcY,-largeurX+symetrieX,300);

  /* 7 */  bezierVertex(-largeurX+symetrieX,300,-largeurX+symetrieX-extremite,290,-largeurX+symetrieX,medianeY);
  /* 8 */  bezierVertex(-largeurX+symetrieX,medianeY,-largeurX+symetrieX,medianeY,-largeurX+symetrieX,medianeY);
  /* 9 */  bezierVertex(-largeurX+symetrieX,medianeY,x1,courbeY,x1,hauteurY); ////////////////////   \u00e0 corriger   //////////////////////////////
  /* 10*/  bezierVertex(x1,hauteurY,x1,hauteurY,x1,y1);

  endShape();

  keyPressed();
  popMatrix();


}

public void keyPressed(){
  if(keyCode==UP){
    fill(0,255,50,130);

    ellipse(x2,78,10,10);
    ellipse(x2,hauteurY,10,10);
    ellipse(x2,courbeY,10,10);
    ellipse(largeurX+symetrieX,medianeY,10,10);
    ellipse(largeurX+symetrieX,300,10,10);

    ellipse(-largeurX+symetrieX,300,10,10);
    ellipse(-largeurX+symetrieX,medianeY,10,10);
    ellipse(x1,courbeY,10,10);
    ellipse(x1,hauteurY,10,10);
    ellipse(x1,100,10,10);

  }
  else if(keyCode==DOWN){
  }

}










int i;

float x1 = -30;
float y1 = 100;

float x2 = 30;
float y2 = 100;

float hauteurX = 30;
float hauteurY = 250;

float medianeX = 30;
float medianeY = 280;

float courbeX = 30;
float courbeY = 280;

float largeurX = 30;
float largeurY = 280;

float angleX = 0.0f;
float angleY = 0.0f;

float symetrieX = 0.0f;
float symetrieY = 0.0f;

float arcX = 0.0f;
float arcY = 300;

int extremite = 0;

ControlP5 controlP5;



public void courbe(float p) {
  courbeY = p;
  controlP5.controller("largeur").setValue(p);
}
public void largeur(float p) {
  largeurX = p;
} 
public void hauteur(float p) {
  hauteurY = p;
}
public void mediane(float p) {
  medianeY = p;
}

public void arc_inferieur(float p) {
  arcY = p;
}

public void symetrie(float p) {
  symetrieX = p;
}

public void extremite(int p) {
  extremite = p;
}
public void fin(float theValue) {
  controlP5.controller("hauteur").setValue(288.5f);
  controlP5.controller("mediane").setValue(289.33f);
  controlP5.controller("largeur").setValue(100);
  controlP5.controller("courbe").setValue(288.70f);
  controlP5.controller("symetrie").setValue(0);
  controlP5.controller("arc_inferieur").setValue(300);
  controlP5.controller("extremite").setValue(0);
}

public void carre(float theValue) {
  controlP5.controller("hauteur").setValue(250);
  controlP5.controller("mediane").setValue(250);
  controlP5.controller("largeur").setValue(100);
  controlP5.controller("courbe").setValue(250);
  controlP5.controller("symetrie").setValue(0);
  controlP5.controller("arc_inferieur").setValue(300);
  controlP5.controller("extremite").setValue(0);
}

public void triangulaire(float theValue) {
  controlP5.controller("hauteur").setValue(250.79f);
  controlP5.controller("mediane").setValue(278.66f);
  controlP5.controller("largeur").setValue(88.33f);
  controlP5.controller("courbe").setValue(250);
  controlP5.controller("symetrie").setValue(0);
  controlP5.controller("arc_inferieur").setValue(300);
  controlP5.controller("extremite").setValue(0);
}

public void arrondi(float theValue) {
  controlP5.controller("hauteur").setValue(243);
  controlP5.controller("mediane").setValue(290.66f);
  controlP5.controller("largeur").setValue(100);
  controlP5.controller("courbe").setValue(291.70f);
  controlP5.controller("symetrie").setValue(0);
  controlP5.controller("arc_inferieur").setValue(300);
  controlP5.controller("extremite").setValue(0);
}

public void arque(float theValue) {
  controlP5.controller("hauteur").setValue(257.30f);
  controlP5.controller("mediane").setValue(288);
  controlP5.controller("largeur").setValue(77.13f);
  controlP5.controller("courbe").setValue(288.70f);
  controlP5.controller("symetrie").setValue(0);
  controlP5.controller("arc_inferieur").setValue(291.60f);
  controlP5.controller("extremite").setValue(13);
}

//////FX

public void x1(float theValue) {
  controlP5.controller("hauteur").setValue(295);
  controlP5.controller("mediane").setValue(295);
  controlP5.controller("largeur").setValue(250);
  controlP5.controller("courbe").setValue(100);
  controlP5.controller("symetrie").setValue(0);
  controlP5.controller("arc_inferieur").setValue(280);
  controlP5.controller("extremite").setValue(50);
}

public void x2(float theValue) {
  controlP5.controller("hauteur").setValue(257.30f);
  controlP5.controller("mediane").setValue(186.66f);
  controlP5.controller("largeur").setValue(288.70f);
  controlP5.controller("courbe").setValue(30);
  controlP5.controller("symetrie").setValue(0);
  controlP5.controller("arc_inferieur").setValue(291.60f);
  controlP5.controller("extremite").setValue(50);
}

public void x3(float theValue) {
  controlP5.controller("hauteur").setValue(254.71f);
  controlP5.controller("mediane").setValue(288.00f);
  controlP5.controller("courbe").setValue(255.00f);
  controlP5.controller("largeur").setValue(30.00f);
  controlP5.controller("symetrie").setValue(0.00f);
  controlP5.controller("arc_inferieur").setValue(300.00f);
  controlP5.controller("extremite").setValue(-10);
}

public void x4(float theValue) {
  controlP5.controller("hauteur").setValue(295);
  controlP5.controller("mediane").setValue(290);
  controlP5.controller("largeur").setValue(250);
  controlP5.controller("courbe").setValue(100);
  controlP5.controller("symetrie").setValue(0);
  controlP5.controller("arc_inferieur").setValue(307);
  controlP5.controller("extremite").setValue(5);
}
  static public void main(String args[]) {
    PApplet.main(new String[] { "--bgcolor=#FFFFFF", "pimpMySerif" });
  }
}
